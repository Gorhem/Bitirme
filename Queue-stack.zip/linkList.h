//@authors
//Mehmet Taha SAHIN 130144049
//Gorhem Gokturk SAKA 130144046
//


#ifndef LINKLIST_H
#define LINKLIST_H
#include <string>


struct Node {
	int data;
	Node* next;
};




#endif